#include "types.h"
#include "stat.h"
#include "user.h"

int main(){
    for(int i=1;i<11;++i){
        printf(1,"%d\n",i);
        sleep(100);
    }
    exit();
}